﻿using lab5;

var klient = new Klient();
klient.Uruchom();