package com.nortexdev.javalab5errs.exceptions;

public class ValidationException extends Exception {
	public ValidationException(String message) {
		super(message);
	}
}
