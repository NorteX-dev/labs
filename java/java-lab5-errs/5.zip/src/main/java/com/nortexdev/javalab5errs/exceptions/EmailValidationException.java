package com.nortexdev.javalab5errs.exceptions;

public class EmailValidationException extends ValidationException {
	public EmailValidationException(String message) {
		super(message);
	}
}
